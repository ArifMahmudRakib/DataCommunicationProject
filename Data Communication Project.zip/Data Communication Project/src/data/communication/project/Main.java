/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data.communication.project;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Main {
    public static void main(String[] args) throws IOException {
    System.out.println("=== Welcome to Transmission System Simulator ===");
    System.out.println("Please select a transmission method:");
    System.out.println("1. B8ZS 2.HDB3");
    Scanner inputScanner = new Scanner(System.in);
    System.out.print("Enter the number of the transmission method: ");
    int selectedTransmissionMethod = inputScanner.nextInt();
    System.out.println();

    Sender sender = new Sender(selectedTransmissionMethod);
    Receiver receiver = new Receiver(selectedTransmissionMethod);

    System.out.println("\nTransmission Completed");
    System.out.println("Transmission Method: " + getTransmissionMethodName(selectedTransmissionMethod));
    System.out.println("Number of Bits Transmitted: " + sender.count);
    System.out.println("Number of Successful Receptions: " + receiver.successCount);
    System.out.println("Number of Error Receptions: " + receiver.errorCount);

    if (receiver.errorCount > 0) {
        float snr = (float) receiver.successCount / receiver.errorCount;
        System.out.println("Signal-to-Noise Ratio (SNR): " + snr);
    } else {
        System.out.println("Signal-to-Noise Ratio (SNR): Infinite (No Errors)");
    }
}

private static String getTransmissionMethodName(int methodNumber) {
    switch (methodNumber) {
        case 1:
            return "B8ZS";
        case 2:
            return "HDB3";
        default:
            return "Unknown";
    }
}
}
