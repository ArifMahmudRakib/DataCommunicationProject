/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data.communication.project;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author User
 */
public class Sender {
    private String inputString;
    private String outputString;
    private FileWriter binaryFileWriter;
    private FileWriter stateFileWriter;
    private FileReader fileReader;
    int count = 0;
    private int transmissionMethod;

    public Sender(int transmissionMethod) throws IOException {
        fileReader = new FileReader("labIn.txt");
        binaryFileWriter = new FileWriter("tempBinary.txt");
        stateFileWriter = new FileWriter("tempState.txt");
        BufferedReader br = new BufferedReader(fileReader);
        int characterCount = 0;
        inputString = "";

        while (true) {
            int character = br.read();
            characterCount++;

            if (character == -1) {
                applicationLayer(inputString, transmissionMethod);
                break;
            }

            char ch = (char) character;
            inputString += ch;

            if (characterCount == 125) {
                applicationLayer(inputString, transmissionMethod);
                characterCount = 0;
                inputString = "";
            }
        }

        binaryFileWriter.close();
        stateFileWriter.close();
    }

    private void applicationLayer(String s, int transmissionMethod) throws IOException {
        String modifiedString = "A-H" + s;
        presentationLayer(modifiedString, transmissionMethod);
    }

    private void presentationLayer(String s, int transmissionMethod) throws IOException {
        String modifiedString = "P-H" + s;
        sessionLayer(modifiedString, transmissionMethod);
    }

    private void sessionLayer(String s, int transmissionMethod) throws IOException {
        String modifiedString = "S-H" + s;
        transportLayer(modifiedString, transmissionMethod);
    }

    private void transportLayer(String s, int transmissionMethod) throws IOException {
        String modifiedString = "T-H" + s;
        networkLayer(modifiedString, transmissionMethod);
    }

    private void networkLayer(String s, int transmissionMethod) throws IOException {
        String modifiedString = "N-H" + s;
        dataLinkLayer(modifiedString, transmissionMethod);
    }

    private void dataLinkLayer(String s, int transmissionMethod) throws IOException {
        String modifiedString = "D-H" + s + "D-T";
        physicalLayer(modifiedString, transmissionMethod);
    }

    private void physicalLayer(String s, int transmissionMethod) throws IOException {
        String modifiedString = "PH-H" + s;
        outputString = "";

        for (int i = 0; i < modifiedString.length(); i++) {
            char c = modifiedString.charAt(i);
            String binaryRepresentation = Integer.toBinaryString(c);
            int binaryRepresentationLength = binaryRepresentation.length();

            if (binaryRepresentationLength != 8) {
                for (int j = 0; j < 8 - binaryRepresentationLength; j++) {
                    binaryRepresentation = "0" + binaryRepresentation;
                }
            }

            outputString += binaryRepresentation;
        }

        binaryFileWriter.write(outputString);
        count++;

        switch (transmissionMethod) {
            case 1:
                System.out.println("Transmitting through B8ZS method");
                b8zs(outputString);
                break;
            case 2:
                System.out.println("Transmitting through HDB3 method");
                hdb3(outputString);
                break;
            default:
                System.out.println("Transmitting through NRZ-I method as default");
                nrzI(outputString);
                break;
        }
    }

    private void nrzI(String s) throws IOException {
        char positiveState = '+';
        char negativeState = '-';
        inputString = "";

        for (int j = 0; j < s.length(); j++) {
            char bit = s.charAt(j);
            int bitValue = Character.getNumericValue(bit);

            if (bitValue == 0) {
                inputString += positiveState;
            } else {
                inputString += negativeState;
                char temp = positiveState;
                positiveState = negativeState;
                negativeState = temp;
            }
        }

        stateFileWriter.write(inputString);
    }

    private void nrzL(String s) throws IOException {
        char positiveState = '+';
        char negativeState = '-';
        inputString = "";

        for (int j = 0; j < s.length(); j++) {
            char bit = s.charAt(j);
            int bitValue = Character.getNumericValue(bit);

            if (bitValue == 0) {
                inputString += positiveState;
            } else {
                inputString += negativeState;
            }
        }

        stateFileWriter.write(inputString);
    }

    private void rz(String s) throws IOException {
        String positiveState = "-+";
        String negativeState = "+-";
        inputString = "";

        for (int j = 0; j < s.length(); j++) {
            char bit = s.charAt(j);
            int bitValue = Character.getNumericValue(bit);

            if (bitValue == 0) {
                inputString += positiveState;
            } else {
                inputString += negativeState;
            }
        }

        stateFileWriter.write(inputString);
    }

    private void manchester(String s) throws IOException {
        String positiveState = "+-";
        String negativeState = "-+";
        inputString = "";

        for (int j = 0; j < s.length(); j++) {
            char bit = s.charAt(j);
            int bitValue = Character.getNumericValue(bit);

            if (bitValue == 0) {
                inputString += positiveState;
            } else {
                inputString += negativeState;
            }
        }

        stateFileWriter.write(inputString);
    }

    private void diffManchester(String s) throws IOException {
        String positiveState = "+-";
        String negativeState = "-+";
        inputString = "";

        for (int j = 0; j < s.length(); j++) {
            char bit = s.charAt(j);
            int bitValue = Character.getNumericValue(bit);

            if (bitValue == 0) {
                inputString += positiveState;
            } else {
                inputString += negativeState;
                String temp = positiveState;
                positiveState = negativeState;
                negativeState = temp;
            }
        }

        stateFileWriter.write(inputString);
    }

    private void ami(String s) throws IOException {
        String positive = "+";
        String negative = "-";
        String zero = "0";
        String prevState = "";
        inputString = "";

        for (int j = 0; j < s.length(); j++) {
            char bit = s.charAt(j);
            int bitValue = Character.getNumericValue(bit);

            if (bitValue == 0) {
                inputString += zero;
            } else {
                if (prevState.equals(positive)) {
                    inputString += negative;
                    prevState = negative;
                } else {
                    inputString += positive;
                    prevState = positive;
                }
            }
        }

        stateFileWriter.write(inputString);
    }

    private void pseudoternary(String s) throws IOException {
        String positive = "+";
        String negative = "-";
        String one = "1";
        String prevState = "";
        inputString = "";

        for (int j = 0; j < s.length(); j++) {
            char bit = s.charAt(j);
            int bitValue = Character.getNumericValue(bit);

            if (bitValue == 1) {
                inputString += one;
            } else {
                if (prevState.equals(positive)) {
                    inputString += negative;
                    prevState = negative;
                } else {
                    inputString += positive;
                    prevState = positive;
                }
            }
        }

        stateFileWriter.write(inputString);
    }

    private void b8zs(String s) throws IOException {
        String positive = "+";
        String negative = "-";
        String zero = "0";
        String prevState = "";
        int countZeros = 0;
        inputString = "";

        for (int j = 0; j < s.length(); j++) {
            char bit = s.charAt(j);
            int bitValue = Character.getNumericValue(bit);

            if (bitValue == 0) {
                countZeros++;

                if (countZeros == 8) {
                    if (prevState.equals(positive)) {
                        inputString = inputString.replace("0000000", "000+-0-+");
                        prevState = positive;
                    } else {
                        inputString = inputString.replace("0000000", "000-+0+-");
                        prevState = negative;
                    }
                } else {
                    inputString += zero;
                }
            } else {
                if (prevState.equals(positive)) {
                    inputString += negative;
                    prevState = negative;
                } else {
                    inputString += positive;
                    prevState = positive;
                }

                countZeros = 0;
            }
        }

        stateFileWriter.write(inputString);
    }

    private void hdb3(String s) throws IOException {
        String positive = "+";
        String negative = "-";
        String zero = "0";
        String prevState = "";
        int countZeros = 0;
        int nonZeroPulse = 0;
        inputString = "";

        for (int j = 0; j < s.length(); j++) {
            char bit = s.charAt(j);
            int bitValue = Character.getNumericValue(bit);

            if (bitValue == 0) {
                countZeros++;

                if (countZeros == 4) {
                    inputString += zero;

                    if (nonZeroPulse % 2 == 0) {
                        if (prevState.equals(positive)) {
                            inputString = inputString.replace("0000", "B00V");
                            prevState = negative;
                        } else {
                            inputString = inputString.replace("0000", "B00V");
                            prevState = positive;
                        }

                        nonZeroPulse += 2;
                    } else {
                        if (prevState.equals(positive)) {
                            inputString = inputString.replace("0000", "000V");
                            prevState = positive;
                        } else {
                            inputString = inputString.replace("0000", "000V");
                            prevState = negative;
                        }

                        nonZeroPulse++;
                    }

                    countZeros = 0;
                } else {
                    inputString += zero;
                }
            } else {
                if (prevState.equals(positive)) {
                    inputString += negative;
                    prevState = negative;
                } else {
                    inputString += positive;
                    prevState = positive;
                }

                countZeros = 0;
                nonZeroPulse++;
            }
        }

        stateFileWriter.write(inputString);
    }

    private void b4b5(String s) throws IOException {
        String tempString = "";
        inputString = "";

        for (int j = 0; j < s.length(); j++) {
            char bit = s.charAt(j);
            int bitValue = Character.getNumericValue(bit);
            tempString += bitValue;

            if ((j + 1) % 4 == 0) {
                if (tempString.equals("0000")) {
                    inputString += "11110";
                } else if (tempString.equals("0001")) {
                    inputString += "01001";
                } else if (tempString.equals("0010")) {
                    inputString += "10100";
                } else if (tempString.equals("0011")) {
                    inputString += "10101";
                } else if (tempString.equals("0100")) {
                    inputString += "01010";
                } else if (tempString.equals("0101")) {
                    inputString += "01011";
                } else if (tempString.equals("0110")) {
                    inputString += "01110";
                } else if (tempString.equals("0111")) {
                    inputString += "01111";
                } else if (tempString.equals("1000")) {
                    inputString += "10010";
                } else if (tempString.equals("1001")) {
                    inputString += "10011";
                } else if (tempString.equals("1010")) {
                    inputString += "10110";
                } else if (tempString.equals("1011")) {
                    inputString += "10111";
                } else if (tempString.equals("1100")) {
                    inputString += "11010";
                } else if (tempString.equals("1101")) {
                    inputString += "11011";
                } else if (tempString.equals("1110")) {
                    inputString += "11100";
                } else if (tempString.equals("1111")) {
                    inputString += "11101";
                }

                tempString = "";
            }
        }

        stateFileWriter.write(inputString);
    }    
    
}
